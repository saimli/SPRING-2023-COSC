function parseScores(scoresString) {
    // Your code here
}

function buildDistributionArray(scoresArray) {
    // Your code here
}

function setTableContent(userInput) {
    // Your code here
}

function bodyLoaded() {
    // The argument passed to writeTableContent can be changed for 
    // testing purposes
    setTableContent("45 78 98 83 86 99 90 59");
}