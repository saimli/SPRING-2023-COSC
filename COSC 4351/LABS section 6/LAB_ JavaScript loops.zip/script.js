function drawTriangle(size) {

   // Your solution goes here
   
}