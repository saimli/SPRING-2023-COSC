function displayElements(){

   const userArray = prompt(); // Code will be tested with other array values as well
   
   /* Your solution goes here */

   
}
