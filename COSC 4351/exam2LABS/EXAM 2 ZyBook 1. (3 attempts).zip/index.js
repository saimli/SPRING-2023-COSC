function calculateAwardPoints(){

   var awardPoints = 0;
   var userTickets = 4; // Code will be tested with other values as well
   
   /* Your solution goes here */

   
}
