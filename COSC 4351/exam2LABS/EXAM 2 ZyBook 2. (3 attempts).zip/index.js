var movie = { 
   name: "Forrest Gump",
   director: "Robert Zemeckis",
   composer: "Alan Silvestri",
   cast: {
      "Tom Hanks": "Forrest Gump",
      "Michael Connor Humphreys": "Young Forrest Gump",
      "Robin Wright": "Jenny Curran",
      "Gary Sinise": "Lieutenant Dan Taylor"
   }
};

/* Your solution goes here */

